-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 24, 2022 at 04:15 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_list`
--

CREATE TABLE `activity_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `image_path` text NOT NULL,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activity_list`
--

INSERT INTO `activity_list` (`id`, `name`, `description`, `status`, `image_path`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'Sangeet Ceremony', '&lt;p style=&quot;text-align: left; margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot; open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot;&gt;&lt;font color=&quot;#000000&quot; face=&quot;arial, sans-serif&quot;&gt;Sangeet is one of the several pre-wedding events which is commonly celebrated by North Indian families now also famous in the South Indian region. A typical Sangeet ceremony involves a lot of singing and dancing where the families of both the bride and the groom join hands to make the evening more interesting.&lt;/font&gt;&lt;br&gt;&lt;/p&gt;', 1, 'uploads/activitys/1.png?v=1643035198', 0, '2022-01-08 13:12:13', '2022-01-24 20:15:37'),
(2, 'Snorkeling', '&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas hendrerit est elit, vitae sagittis lorem lobortis in. Donec vulputate, metus vel hendrerit pulvinar, lectus arcu cursus ipsum, vitae tincidunt erat velit sit amet tortor. Integer sit amet ex pellentesque purus hendrerit rhoncus. Aliquam aliquet hendrerit turpis, ut imperdiet lacus condimentum at. Etiam aliquet non nunc a vehicula. Cras lobortis, velit sed sollicitudin bibendum, tellus arcu lobortis dolor, rutrum ullamcorper est ante vitae ipsum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Maecenas non pretium sapien. Etiam a fermentum risus.&lt;/p&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;Ut tempus urna non consequat tincidunt. Vestibulum imperdiet ultrices malesuada. In consequat luctus nisl imperdiet convallis. Donec auctor tortor id nisl varius suscipit. Aliquam posuere ex risus, a laoreet risus vulputate nec. Ut fringilla nibh lacus, quis sagittis odio bibendum quis. Phasellus odio ipsum, accumsan vehicula diam ac, condimentum aliquam tellus.&lt;/p&gt;', 1, 'uploads/activitys/2.png?v=1641618857', 1, '2022-01-08 13:14:17', '2022-01-24 20:11:58'),
(3, 'Haldi', '&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot; open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot;&gt;&lt;span style=&quot;color: rgb(32, 33, 36); font-family: Roboto, arial, sans-serif; font-size: 13px; text-align: left; white-space: pre-wrap;&quot;&gt;The Haldi ceremony is a ritual holy bath also known as pithi ceremony, which is one of the pre-wedding ceremonies in India. Turmeric (haldi), oil and water are applied to both the bride and groom by married women on the morning of the wedding. The mixture is believed to bless the couple before the wedding. It is known to have properties that leave the skin fair and glowing. The haldi in some Indian communities is considered auspicious and also signifies protection.&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot; open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot;&gt;&lt;span style=&quot;color: rgb(32, 33, 36); font-family: Roboto, arial, sans-serif; font-size: 13px; text-align: left; white-space: pre-wrap;&quot;&gt;The auspiciousness of this ingredient and its colour brings prosperity to the couple to start off their new life together. In many other cultures, this is also the reason the bride and groom wear yellow clothes on their wedding day. It is known by several names in different regions, like ubtan, mandha and tel baan.&lt;/span&gt;&lt;span style=&quot;color: rgb(32, 33, 36); font-family: Roboto, arial, sans-serif; font-size: 13px; text-align: left; white-space: pre-wrap;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, 'uploads/activitys/3.png?v=1643035119', 0, '2022-01-08 13:14:58', '2022-01-24 20:11:35'),
(4, 'Mehendi', '&lt;div class=&quot;oIy2qc&quot; jsname=&quot;dTKtvb&quot; data-message-text=&quot;Mehndi-or mehendi or henna-is an ancient form of body art, originating in India and across South Asia and the Middle East. A Mehndi party is the pre-wedding celebration in Hindu and Sikh culture when the bride has the red-orange mehndi &amp;quot;stain&amp;quot; applied to her palms, back of hands, and feet. Typically held the day before the wedding, the event often has a lounge feel, with colorful pillows. Although these parties were traditionally held in the bride&#039;s home, today&#039;s bride is opting to host it at an&quot; style=&quot;-webkit-tap-highlight-color: transparent; color: rgb(32, 33, 36); font-size: 13px; line-height: 20px; padding-top: 0px; white-space: pre-wrap; overflow-wrap: break-word; font-family: Roboto, arial, sans-serif;&quot;&gt;Mehndi-or mehendi or henna-is an ancient form of body art, originating in India and across South Asia and the Middle East. A Mehndi party is the pre-wedding celebration in Hindu and Sikh culture when the bride has the red-orange mehndi &quot;stain&quot; applied to her palms, back of hands, and feet. Typically held the day before the wedding, the event often has a lounge feel, with colorful pillows. Although these parties were traditionally held in the bride&#039;s home, today&#039;s bride is opting to host it at an&lt;/div&gt;&lt;div class=&quot;oIy2qc&quot; jsname=&quot;dTKtvb&quot; data-message-text=&quot;Although these parties were traditionally held in the bride&#039;s home, today&#039;s bride is opting to host it at an outside venue.&quot; style=&quot;-webkit-tap-highlight-color: transparent; color: rgb(32, 33, 36); font-size: 13px; line-height: 20px; padding-top: 10px; white-space: pre-wrap; overflow-wrap: break-word; font-family: Roboto, arial, sans-serif;&quot;&gt;Although these parties were traditionally held in the bride&#039;s home, today&#039;s bride is opting to host it at an outside venue.&lt;/div&gt;', 1, 'uploads/activitys/4.png?v=1643035143', 0, '2022-01-08 13:15:27', '2022-01-24 20:14:09'),
(5, 'test', '&lt;p&gt;test&lt;/p&gt;', 0, 'uploads/activitys/5.png?v=1641618949', 1, '2022-01-08 13:15:49', '2022-01-08 13:16:19');

-- --------------------------------------------------------

--
-- Table structure for table `message_list`
--

CREATE TABLE `message_list` (
  `id` int(30) NOT NULL,
  `fullname` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message_list`
--

INSERT INTO `message_list` (`id`, `fullname`, `contact`, `email`, `message`, `status`, `date_created`) VALUES
(4, 'Dheephi D', '8787544564', 'dheepti@gmail.com', 'Hey there, Loved using your Website. Great Work.\r\n', 1, '2022-01-24 20:40:02');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_list`
--

CREATE TABLE `reservation_list` (
  `id` int(30) NOT NULL,
  `code` varchar(100) NOT NULL,
  `room_id` int(30) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `fullname` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=Pending, 1 = Confirmed, 2=Cancelled',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation_list`
--

INSERT INTO `reservation_list` (`id`, `code`, `room_id`, `check_in`, `check_out`, `fullname`, `contact`, `email`, `address`, `status`, `date_created`, `date_updated`) VALUES
(4, '202201-0003', 2, '2022-01-28', '2022-01-28', 'Avinash Kumar', '8468468446', 'avinash2k20@gmail.com', 'Near Ms Palya', 0, '2022-01-24 20:34:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `room_list`
--

CREATE TABLE `room_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `type` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `image_path` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_list`
--

INSERT INTO `room_list` (`id`, `name`, `type`, `description`, `price`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'Rishikesh', 'Family', '&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;&lt;br&gt;&lt;/p&gt;', 1200000, 'uploads/rooms/1.png?v=1643035648', 1, 0, '2022-01-08 09:53:41', '2022-01-24 20:17:28'),
(2, 'Udaipur Palace', 'Double', '&lt;p&gt;UDAIPUR&lt;/p&gt;&lt;p&gt;- Beautiful Location&lt;/p&gt;&lt;p&gt;-Celebrity post&lt;/p&gt;', 300000, 'uploads/rooms/2.png?v=1643035963', 1, 0, '2022-01-08 10:16:45', '2022-01-24 20:22:43'),
(3, 'Goa - Beach wedding', 'Family', '&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;Goa - Beach wedding&lt;/p&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;-Private pools&lt;/p&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;-Great Scenic Beaches&lt;/p&gt;', 3500, 'uploads/rooms/3.png?v=1643036062', 1, 0, '2022-01-08 10:17:23', '2022-01-24 20:24:22'),
(4, 'Room 103', 'Double', '&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;Etiam et massa ligula. Donec lacinia purus ut ex malesuada, at aliquam dolor laoreet. Proin hendrerit vestibulum quam. Praesent metus diam, volutpat sit amet leo nec, placerat facilisis quam. Pellentesque quis mauris ut erat tristique bibendum. Aliquam molestie massa quis libero vestibulum ultrices. Aliquam odio tellus, tincidunt ut arcu eu, efficitur fringilla leo.&lt;/p&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px;&quot;&gt;Ut sed dui sed sapien tincidunt aliquet. Aenean sodales sollicitudin nibh a porta. Nullam ac commodo lorem. Duis tempus elit in turpis efficitur feugiat. Pellentesque semper auctor lacus, et ullamcorper magna pulvinar eget. Fusce molestie vitae elit ac ornare. Mauris rutrum a felis eget lacinia.&lt;/p&gt;', 1300, 'uploads/rooms/4.png?v=1641608280', 1, 1, '2022-01-08 10:17:59', '2022-01-24 20:24:39'),
(5, 'Room 105', 'Double', '&lt;p&gt;&lt;span style=&quot;text-align: justify;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas hendrerit est elit, vitae sagittis lorem lobortis in. Donec vulputate, metus vel hendrerit pulvinar, lectus arcu cursus ipsum, vitae tincidunt erat velit sit amet tortor. Integer sit amet ex pellentesque purus hendrerit rhoncus. Aliquam aliquet hendrerit turpis, ut imperdiet lacus condimentum at. Etiam aliquet non nunc a vehicula. Cras lobortis, velit sed sollicitudin bibendum, tellus arcu lobortis dolor, rutrum ullamcorper est ante vitae ipsum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Maecenas non pretium sapien. Etiam a fermentum risus.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;text-align: justify;&quot;&gt;In a orci laoreet, convallis nibh sed, pellentesque elit. Mauris in ipsum justo. Aliquam maximus dapibus auctor. Nulla sodales varius dui, quis ultrices nulla vulputate et. Suspendisse id ligula justo. Etiam quis ligula sit amet purus hendrerit blandit. Mauris ut egestas magna. In tincidunt euismod tincidunt.&lt;/span&gt;&lt;span style=&quot;text-align: justify;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1600, 'uploads/rooms/5.png?v=1641608319', 1, 1, '2022-01-08 10:18:39', '2022-01-24 20:24:44');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'WEDDING RESERVATION SYSTEM'),
(6, 'short_name', '1SG19IS008 & 1SG19IS017'),
(11, 'logo', 'uploads/logo-1643034724.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover-1643034822.png'),
(15, 'content', 'Array'),
(16, 'email', 'avinashAndanjali@gmail.com'),
(17, 'contact', '09854698789 / 7894563254'),
(18, 'from_time', '11:00'),
(19, 'to_time', '21:30'),
(20, 'address', 'Sapthagiri College Of Engineering\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '0=not verified, 1 = verified',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `status`, `date_added`, `date_updated`) VALUES
(1, 'AVINASH ', NULL, 'KUMAR', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatar-1.png?v=1643034908', NULL, 1, 1, '2021-01-20 14:02:37', '2022-01-24 20:05:08'),
(5, 'Anjali', NULL, 'Jha', 'Anjali Jha', '12ed51686a83dff335014f5960cf94a4', 'uploads/avatar-5.png?v=1643036150', NULL, 2, 1, '2022-01-08 14:21:46', '2022-01-24 20:25:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_list`
--
ALTER TABLE `activity_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_list`
--
ALTER TABLE `message_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservation_list`
--
ALTER TABLE `reservation_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `room_list`
--
ALTER TABLE `room_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_list`
--
ALTER TABLE `activity_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `message_list`
--
ALTER TABLE `message_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reservation_list`
--
ALTER TABLE `reservation_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `room_list`
--
ALTER TABLE `room_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservation_list`
--
ALTER TABLE `reservation_list`
  ADD CONSTRAINT `reservation_list_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room_list` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
